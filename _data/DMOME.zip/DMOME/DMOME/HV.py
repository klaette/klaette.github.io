import numpy as np


def HV(PopObj, PF):
    # # 归一化帕累托解集和目标函数集
    # normalized_pareto_set = (PF - np.min(PF, axis=0)) / (np.max(PF, axis=0) - np.min(PF, axis=0))
    # normalized_objective_set = (PopObj - np.min(PopObj, axis=0)) / (np.max(PopObj, axis=0) - np.min(PopObj, axis=0))
    # reference_point = np.max(normalized_objective_set, axis=0)
    # # 计算每个归一化帕累托解的超体积贡献
    # hv_contributions = np.maximum(np.minimum(reference_point - normalized_objective_set, reference_point), 0)
    # hv_contributions = np.prod(hv_contributions, axis=1)
    #
    # # 计算HV
    # Score = np.sum(hv_contributions)

    n, m = PF.shape
    normalized_objective_set = PopObj / np.max(PopObj, axis=0)
    Score = 0.0
    # 计算最大目标函数值，作为参考点
    ref_point = np.max(normalized_objective_set, axis=0)
    # 逐个解计算超体积贡献
    for i in range(n):
        # 计算每个解对应的超体积贡献
        contrib = np.prod(ref_point -  normalized_objective_set[i])  # numpy.prod,它的作用是计算数组中所有元素的乘积
        Score += contrib
    # 归一化超体积值
    Score /= np.prod(ref_point)
    return Score

#     N, M = np.shape(PopObj)
#     RefPoint = np.max(PF, axis=0) * 1.1
#     PopObj = PopObj[~np.any(PopObj > np.tile(RefPoint, (N, 1)), axis=1), :]
#
#     if len(PopObj) == 0:
#         Score = 0
#     elif M < 5:
#         pl = np.sort(PopObj, axis=0)
#         S = [[1, pl]]
#
#         for k in range(1, M):
#             S_ = []
#             for i in range(len(S)):
#                 Stemp = Slice(np.array(S[i][1]), k, RefPoint)
#                 for j in range(len(Stemp)):
#                     temp = [np.array(Stemp[j][0]) * np.array(S[i][0]), Stemp[j][1]]
#                     S_ = Add(temp, S_)
#             S = S_
#
#         Score = 0
#         for i in range(len(S)):
#             p = Head(np.array(S[i][1]))
#             Score += np.array(S[i][0]) * np.abs(p[M - 1] - RefPoint[M - 1])
#     else:
#         SampleNum = 1000000
#         MaxValue = RefPoint
#         MinValue = np.min(PopObj, axis=0)
#         Samples = MinValue + np.random.rand(SampleNum, M) * (MaxValue - MinValue)
#         Domi = np.zeros(SampleNum, dtype=bool)
#
#         for i in range(len(PopObj)):
#             Domi[np.all(PopObj[i, :] <= Samples, axis=1)] = True
#
#         Score = np.prod(MaxValue - MinValue) * np.sum(Domi) / SampleNum
#
#     return Score
#
#
# def Slice(pl, k, RefPoint):
#     p = Head(pl)
#     pl = Tail(pl)
#     ql = []
#     S = []
#
#     while len(pl) > 0:
#         ql = Insert(p, k + 1, ql)
#         p_ = Head(pl)
#         cell_ = [np.abs(p[k] - p_), ql]
#         S.append(cell_)
#         p = p_
#         pl = Tail(pl)
#
#     ql = Insert(p, k + 1, ql)
#     cell_ = [np.abs(p[k] - RefPoint[k]), ql]
#     S.append(cell_)
#
#     return S
#
#
# def Insert(p, k, pl):
#     flag1 = False
#     flag2 = False
#     ql = []
#     hp = Head(pl)
#
#     while len(pl) > 0 and hp[k - 1] < p[k - 1]:
#         ql.append(hp)
#         pl = Tail(pl)
#         hp = Head(pl)
#
#     ql.append(p)
#     m = len(p)
#
#     while len(pl) > 0:
#         q = Head(pl)
#         for i in range(k - 1, m):
#             if p[i] < q[i]:
#                 flag1 = True
#             else:
#                 if p[i] > q[i]:
#                     flag2 = True
#
#         if not (flag1 and not flag2):
#             ql.append(Head(pl))
#
#         pl = Tail(pl)
#
#     return ql
#
#
# def Head(pl):
#     if len(pl) == 0:
#         p = []
#     else:
#         p = pl[0]
#
#     return p
#
#
# def Tail(pl):
#     if len(pl) < 2:
#         ql = []
#     else:
#         ql = pl[1:]
#
#     return ql
#
#
# def Add(cell_, S):
#     n = len(S)
#     m = 0
#
#     for k in range(n):
#         if np.array_equal(cell_[1], S[k][1]):
#             S[k][0] += cell_[0]
#             m = 1
#             break
#
#     if m == 0:
#         S.append(cell_)
#
#     S_ = S
#
#     return S_