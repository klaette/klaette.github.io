# coding:utf-8
import numpy as np

def CalfitFJFP(p_chrom,m_chrom,FJ,a_chrom,f_index,A,N,H,TM,time,TransTime,machine_idletime, TransTime_Oper):
    #processing power and idle power
    SH=len(p_chrom)
    Ep=4;Es=1;Et=1;
    NT=0; NI=0
    opmax=int(max(H))
    #initial finish time matrix to record the finish time of each operation
    finish=np.zeros(shape=(N,opmax))
    start = np.zeros(shape=(N, opmax))
    #machine finish time
    mt=np.zeros(TM)
    # pre-operation in the same job: selected machine
    prema=np.zeros(shape=(N,opmax),dtype=int)
    #sign all operation
    s1=p_chrom
    s2=np.zeros(SH,dtype=int)
    p=np.zeros(N,dtype=int)
    fitness=np.zeros(2)
    for i in range(SH):
        p[s1[i]]=p[s1[i]]+1
        s2[i]=p[s1[i]]
    #assign the machine to each operation from machine selection vector
    mm=np.zeros(SH,dtype=int)
    # assign the AGV to each operation from AGV selection vector
    aa=np.zeros(SH,dtype=int)
    for i in range(SH):
        t1=s1[i]
        t2=s2[i]
        t4=0
        for k in range(t1):#sum from 0 to t1-1
            t4=t4+H[k]
        mm[i]=m_chrom[t4+t2-1]
        aa[i]=a_chrom[t4+t2-1]
    #initial total workload and total idle time and total transportation time
    TWL=0;TIT=0;TTT=0
    AGV_Ope = np.zeros(shape=(N,5),dtype=int) #record from start to the end position of machines that AGVs transfer operations
    AGV_Pos = np.zeros(A,dtype=int) #record the past and current positions of AGV
    AGV_Time = np.zeros(A,dtype=int)
    AGV_Pos[0] = 5
    AGV_Pos[1] = 5


    #start decoding
    for i in range(SH):
        # because array index starts with 0 in python, number in M start from 1,
        # number in time start from 0, thus number of m_chrom need to miner 1
        t1=s1[i];t2=s2[i]-1;t3=mm[i]; t5=aa[i]
        AGV_Ope[t1][t2] = t5+1
        if s2[i]==1:
            AGV_Time[t5] = AGV_Time[t5] + TransTime[AGV_Pos[t5]][5] + TransTime[5][t3]
            TTT = TTT + TransTime[AGV_Pos[t5]][5] + TransTime[5][t3]
            TransTime_Oper[t1][t2] = TransTime[AGV_Pos[t5]][5] + TransTime[5][t3]
            if AGV_Pos[t5] == 5:
                NT = NT + 1
            else:
                NT = NT + 2
            AGV_Pos[t5] = t3
            if AGV_Time[t5] > mt[t3]:
                TIT =TIT + (AGV_Time[t5] - mt[t3])
                machine_idletime[f_index][t3] = machine_idletime[f_index][t3] + (AGV_Time[t5] - mt[t3])
                NI = NI+1
            AGV_Time[t5] = max(AGV_Time[t5], mt[t3])
            start[t1][t2] = AGV_Time[t5]
            finish[t1][t2] = start[t1][t2] + time[f_index][t1][t2][t3]
            mt[t3] = finish[t1][t2]
            prema[t1][t2] = t3
            TWL=TWL+time[f_index][t1][t2][t3]
        else: # is not the first operation
            AGV_Time[t5] = max(AGV_Time[t5]+ TransTime[AGV_Pos[t5]][prema[t1][t2 - 1]], finish[t1][t2 - 1])
            AGV_Time[t5] = AGV_Time[t5]  + TransTime[prema[t1][t2 - 1]][t3]
            TTT = TTT + TransTime[AGV_Pos[t5]][prema[t1][t2 - 1]] + TransTime[prema[t1][t2 - 1]][t3]
            TransTime_Oper[t1][t2] = TransTime[AGV_Pos[t5]][prema[t1][t2 - 1]] + TransTime[prema[t1][t2 - 1]][t3]
            if AGV_Pos[t5] == prema[t1][t2 - 1] and prema[t1][t2 - 1] == t3:
                NT = NT + 0
            elif AGV_Pos[t5] == prema[t1][t2 - 1] or prema[t1][t2 - 1] == t3:
                NT = NT + 1
            else:
                NT = NT + 2
            if AGV_Time[t5] > mt[t3]:
                TIT = TIT + (AGV_Time[t5] - mt[t3])
                machine_idletime[f_index][t3] = machine_idletime[f_index][t3] + (AGV_Time[t5] - mt[t3])
                NI = NI + 1
            start[t1][t2] = max(AGV_Time[t5],mt[t3])
            finish[t1][t2] = start[t1][t2] + time[f_index][t1][t2][t3]
            mt[t3] = finish[t1][t2]
            AGV_Pos[t5] = t3
            prema[t1][t2] = t3
            TWL = TWL + time[f_index][t1][t2][t3]

    fitness[0]=mt[0]
    for i in range(1,TM):
        if mt[i]>fitness[0]:
            fitness[0]=mt[i]
    fitness[1]=TWL*Ep+TIT*Es+TTT*Et
    #print(fitness[0],fitness[1],TWL,TIT)
    return fitness[0],fitness[1], NT, NI, machine_idletime, TransTime_Oper

def CalfitDHFJFP(p_chrom,m_chrom,f_chrom,a_chrom,A,N,H,SH,F,TM,time,TransTime, machine_idletime, TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    fitness = np.zeros(2)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    P0=[];P=[];FJ=[]
    for f in range(F):
        P.append([])
        FJ.append([])

    for i in range(SH):
        t1=s1[i]
        t2=s2[i]
        t3=f_chrom[t1]
        P[t3].append(p_chrom[i])
    for i in range(N):
        t3=f_chrom[i]
        FJ[t3].append(i)
    sub_f_fit=np.zeros(shape=(F,2))

    for f in range(F):
        sub_f_fit[f][0],sub_f_fit[f][1],NT,NI, machine_idletime, TransTime_Oper=CalfitFJFP(P[f],m_chrom,FJ[f],a_chrom,f,A,N,H,TM,time,TransTime,machine_idletime, TransTime_Oper)

    fit1=sub_f_fit[0][0]
    fit3=0;fit2=0
    for f in range(F):
        fit2=sub_f_fit[f][1]+fit2
        if fit1<sub_f_fit[f][0]:
            fit1=sub_f_fit[f][0]
            fit3=f
    return fit1,fit2,fit3,NT,NI, machine_idletime, TransTime_Oper


def CalfitFJFP2(p_chrom,m_chrom,a_chrom,A,N,H,TM,time,TransTime, Ep, TransTime_Oper):
    # processing power and idle power
    SH = len(p_chrom)
    Es = 1.0
    Et = 3.5
    NT = 0
    NI = 0
    opmax = int(max(H))
    # initial finish time matrix to record the finish time of each operation
    finish = np.zeros(shape=(N, opmax))
    start = np.zeros(shape=(N, opmax))
    # machine finish time
    mt = np.zeros(TM)
    # pre-operation in the same job: selected machine
    prema = np.zeros(shape=(N, opmax), dtype=int)
    # sign all operation
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    fitness = np.zeros(2)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    # assign the machine to each operation from machine selection vector
    mm = np.zeros(SH, dtype=int)
    # assign the AGV to each operation from AGV selection vector
    aa = np.zeros(SH, dtype=int)
    for i in range(SH):
        t1 = s1[i]
        t2 = s2[i]
        t4 = 0
        for k in range(t1):  # sum from 0 to t1-1
            t4 = t4 + H[k]
        mm[i] = m_chrom[t4 + t2 - 1]
        aa[i] = a_chrom[t4 + t2 - 1]
    # initial total workload and total idle time and total transportation time
    TWL = 0.0
    TIT = 0.0
    TTT = 0.0
    TPE = 0.0 #总加工能耗
    AGV_Ope = np.zeros(shape=(N, opmax),
                       dtype=int)  # record from start to the end position of machines that AGVs transfer operations
    AGV_Pos = np.zeros(A, dtype=int)  # record the past and current positions of AGV
    AGV_Time = np.zeros(A, dtype=float)
    AGV_Pos[0] = TM
    AGV_Pos[1] = TM

    # start decoding
    for i in range(SH):
        # because array index starts with 0 in python, number in M start from 1,
        # number in time start from 0, thus number of m_chrom need to miner 1
        t1 = s1[i];
        t2 = s2[i] - 1;
        t3 = mm[i];
        t5 = aa[i]
        AGV_Ope[t1][t2] = t5 + 1
        if s2[i] == 1:
            AGV_Time[t5] = AGV_Time[t5] + TransTime[AGV_Pos[t5]][TM] + TransTime[TM][t3]
            TTT = TTT + TransTime[AGV_Pos[t5]][TM] + TransTime[TM][t3]
            TransTime_Oper[t1][t2] = TransTime[AGV_Pos[t5]][TM] + TransTime[TM][t3]
            if AGV_Pos[t5] == TM:
                NT = NT + 1
            else:
                NT = NT + 2
            AGV_Pos[t5] = t3
            if AGV_Time[t5] > mt[t3]:
                TIT = TIT + (AGV_Time[t5] - mt[t3])
                NI = NI + 1
            AGV_Time[t5] = max(AGV_Time[t5], mt[t3])
            start[t1][t2] = AGV_Time[t5]
            finish[t1][t2] = start[t1][t2] + time[t1][t2][t3]
            mt[t3] = finish[t1][t2]
            prema[t1][t2] = t3
            TWL = TWL + time[t1][t2][t3]
            TPE = TPE + time[t1][t2][t3] * Ep[t3]
        else:  # is not the first operation
            AGV_Time[t5] = max(AGV_Time[t5] + TransTime[AGV_Pos[t5]][prema[t1][t2 - 1]], finish[t1][t2 - 1])
            AGV_Time[t5] = AGV_Time[t5] + TransTime[prema[t1][t2 - 1]][t3]
            TTT = TTT + TransTime[AGV_Pos[t5]][prema[t1][t2 - 1]] + TransTime[prema[t1][t2 - 1]][t3]
            TransTime_Oper[t1][t2] = TransTime[AGV_Pos[t5]][prema[t1][t2 - 1]] + TransTime[prema[t1][t2 - 1]][t3]
            if AGV_Pos[t5] == prema[t1][t2 - 1] and prema[t1][t2 - 1] == t3:
                NT = NT + 0
            elif AGV_Pos[t5] == prema[t1][t2 - 1] or prema[t1][t2 - 1] == t3:
                NT = NT + 1
            else:
                NT = NT + 2
            if AGV_Time[t5] > mt[t3]:
                TIT = TIT + (AGV_Time[t5] - mt[t3])
                NI = NI + 1
            start[t1][t2] = max(AGV_Time[t5], mt[t3])
            finish[t1][t2] = start[t1][t2] + time[t1][t2][t3]
            mt[t3] = finish[t1][t2]
            AGV_Pos[t5] = t3
            prema[t1][t2] = t3
            TWL = TWL + time[t1][t2][t3]
            TPE = TPE + time[t1][t2][t3] * Ep[t3]

    fitness[0] = mt[0]
    for i in range(1, TM):
        if mt[i] > fitness[0]:
            fitness[0] = mt[i]
    fitness[1] = TPE + TIT * Es + TTT * Et
    return fitness[0], fitness[1], NT, NI, TransTime_Oper

def CalfitDHFJFP2(p_chrom,m_chrom,f_chrom,a_chrom,A,N,H,SH,F,TM,time,TransTime):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    fitness = np.zeros(2)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    P0=[];P=[];FJ=[]
    for f in range(F):
        P.append([])
        FJ.append([])

    for i in range(SH):
        t1=s1[i]
        t2=s2[i]
        t3=f_chrom[t1]
        P[t3].append(p_chrom[i])
    for i in range(N):
        t3=f_chrom[i]
        FJ[t3].append(i)
    sub_f_fit=np.zeros(shape=(F,2))

    for f in range(F):
        sub_f_fit[f][0],sub_f_fit[f][1],NT,NI=CalfitFJFP2(P[f],m_chrom,FJ[f],a_chrom,f,A,N,H,TM,time,TransTime)

    fit1=sub_f_fit[0][0]
    fit3=0;fit2=0
    for f in range(F):
        fit2=sub_f_fit[f][1]+fit2
        if fit1<sub_f_fit[f][0]:
            fit1=sub_f_fit[f][0]
            fit3=f
    return fit1,fit2,fit3,NT,NI

