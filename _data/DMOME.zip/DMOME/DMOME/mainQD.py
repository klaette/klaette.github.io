# coding:utf-8
import copy

from DataRead import DataReadDHFJSP
import numpy as np
import os
from Initial import GHInitial
from inital import initial
from fitFJSP import *
from Tselection import *
from EA import *
from Tool import *
from FastNDSort import FastNDS
from EnergySave import EnergysavingDHFJSP
from LocalSearch import *
from DRL_model import DQN
import torch
from GD import GD
from IGD import IGD
from HV import HV
from quality_indicator import *
from Update_FeatureSpace import *
from GenerateInstances import *
from quality_indicator import *
import time

Combination=[[20,5],[20,8],[20,10],\
             [30,5],[30,8],[30,10],[40,5],\
             [40,8],[40,10],[50,5],[50,8],[50,10],\
             [80,5],[80,8],[80,10],[100,5],\
             [100,8],[100,10]]

datapath='../DATASET/'
FileName=[];ResultPath=[]
Layout=[]
for i in range(18):
    J=Combination[i][0]
    Fac=Combination[i][1]
    O=5
    temp = datapath +  str(J) +'J' + str(Fac)+ 'F' + '.txt'
    temp2 = str(J) +'J' + str(Fac)+ 'F'
    FileName.append(temp)
    ResultPath.append(temp2)


for k in range(1,5):
    temp3 = datapath + 'Layout' + str(k) + '.txt'
    Layout.append(temp3)

TF=18
FileName=np.array(FileName);FileName.reshape(TF,1)
ResultPath=np.array(ResultPath);ResultPath.reshape(TF,1)
#read the parameter of algorithm such as popsize, crossover rate, mutation rate
f= open("parameter.txt", "r", encoding='utf-8')
ps,Pc,Pm,lr,batch_size,EPSILON,GAMMA,MEMORY_CAPACITY = f.read().split(' ')
ps=int(ps);Pc=float(Pc);Pm=float(Pm);lr=float(lr);batch_size=int(batch_size)
EPSILON=float(EPSILON);GAMMA=float(GAMMA);MEMORY_CAPACITY=int(MEMORY_CAPACITY)
IndependentRun=10

lr=0.01;batch_size=5
EPSILON = 0.85               # greedy policy
GAMMA = 0.8               # reward discount
MEMORY_CAPACITY = 50

TARGET_REPLACE_ITER = 5   # target update frequency
N_ACTIONS = 5 # 8种候选的算子
EPOCH=6
A = 2
P = 5
print(torch.cuda.is_available())
f.close()
#execute algorithm for each instance
CCF=0
for file in range(CCF,CCF+18):
    if CCF < 5:
        L = 0
    elif 5 <= CCF < 10 :
        L = 1
    elif 10 <= CCF < 15 :
        L = 2
    else:
        L = 3
    N, TM, H, SH, NM, M, ptime, TransTime, Ep = GenerateInstances(Combination, file)
    # N, TM, H, SH, NM, M, ptime, TransTime = GenerateRealInstances1(Combination, CCF)
    # N, TM, H, SH, NM, M, ptime, TransTime, Ep = GenerateRealInstances2(Combination, CCF)
    # N,F,TM,H,SH,NM,M,time,ProF,TransTime=DataReadDHFJSP(FileName[file],Layout[L])
    MaxNFEs=10*SH*TM
    epsilon = 0.8
    alpha = 0.4
    gamma = 0.8

    #create filepath to store the pareto solutions set for each independent run
    respath='MQD\\';sprit='\\'
    respath=respath+ResultPath[file]
    isExist=os.path.exists(respath)
    #if the result path has not been created
    if not isExist:
        currentpath=os.getcwd()
        os.makedirs(currentpath+sprit+respath)
    print(ResultPath[file],'is being Optimizing\n')

    Feature_Table = np.zeros(shape=(SH * 2, SH, P, 2))
    Feature_bestPchorm = np.zeros(shape=(SH * 2, SH, P, SH), dtype=int)
    Feature_bestMchorm = np.zeros(shape=(SH * 2, SH, P, SH), dtype=int)
    Feature_bestAchorm = np.zeros(shape=(SH * 2, SH, P, SH), dtype=int)

    for rround in range(35):
        start_time = time.time()

        p_chrom, m_chrom, a_chrom = initial(N, H, SH, NM, M, ps, A)
        NT = np.zeros(shape=0, dtype=int)
        NI = np.zeros(shape=0, dtype=int)
        fitness = np.zeros(shape=(ps, 2), dtype=int)
        NFEs=0
        opmax = int(max(H))
        AP = []
        AM = []
        AA = []
        AFit = []
        for i in range(ps):
            TransTime_Oper = np.zeros(shape=(N, opmax))
            fitness[i][0], fitness[i][1], NT2, NI2, TransTime_Oper = CalfitFJFP2(p_chrom[i, :], m_chrom[i, :], a_chrom[i], A, N, H, TM, ptime, TransTime, Ep, TransTime_Oper)
            if i == 0:
                NT = np.append(NT, NT2)
                NI = np.append(NI, NI2)
            Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, reward = Update_FeatureSpace(
                p_chrom[i, :], m_chrom[i, :], a_chrom[i, :], fitness[i, :], Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, NT2, NI2, P)

        QDP = np.zeros(shape=0, dtype=float)
        QDM = np.zeros(shape=0, dtype=float)
        QDA = np.zeros(shape=0, dtype=float)
        QDFit = np.zeros(shape=0, dtype=float)

        QDP = Feature_bestPchorm[NT[0]][NI[0]][0][:]
        QDM = Feature_bestMchorm[NT[0]][NI[0]][0][:]
        QDA = Feature_bestAchorm[NT[0]][NI[0]][0][:]
        QDFit = Feature_Table[NT[0]][NI[0]][0][:]

        for k in range(len(NT)):
            nonzero_count3 = np.count_nonzero(Feature_Table[NT[k]][NI[k]][:, 0])
            for kk in range(nonzero_count3):
                QDP = np.vstack((QDP, Feature_bestPchorm[NT[k]][NI[k]][kk][:]))
                QDM = np.vstack((QDM, Feature_bestMchorm[NT[k]][NI[k]][kk][:]))
                QDA = np.vstack((QDA, Feature_bestAchorm[NT[k]][NI[k]][kk][:]))
                QDFit = np.vstack((QDFit, Feature_Table[NT[k]][NI[k]][kk][:]))

        PF = pareto(QDFit)
        if len(AFit) == 0:
            AP = copy.copy(QDP[PF, :])
            AM = copy.copy(QDM[PF, :])
            AA = copy.copy(QDA[PF, :])
            AFit = copy.copy(QDFit[PF, :])
        AP, AM, AA, AFit = DeleteReaptE(AP, AM, AA, AFit)


        # build model
        N_STATES = 2 * SH + SH
        CountOpers = np.zeros(N_ACTIONS)
        PopCountOpers = []
        dq_net = DQN(N_STATES, N_ACTIONS, BATCH_SIZE=batch_size, LR=lr, EPSILON=EPSILON, GAMMA=GAMMA, \
                     MEMORY_CAPACITY=MEMORY_CAPACITY, TARGET_REPLACE_ITER=TARGET_REPLACE_ITER)
        Loss = []
        current_state = np.zeros(N_STATES, dtype=int)
        next_state = np.zeros(N_STATES, dtype=int)
        actionnum = np.zeros(N_ACTIONS, dtype=int)

        while NFEs<MaxNFEs:
            print(FileName[file]+' round ',rround+1,'iter ',NFEs)

            for count in range(batch_size):
                PF = pareto(AFit)
                AP = AP[PF, :]
                AM = AM[PF, :]
                AA = AA[PF, :]
                AFit = AFit[PF, :]
                BP, BM, BA, BFit = DeleteReaptE(AP, AM, AA, AFit)
                Plen = BP.shape[0]

                Fit1 = np.zeros(2)
                Fit2 = np.zeros(2)
                index = int(np.floor(random.random() * len(NT)))

                nonzero_count = np.count_nonzero(Feature_Table[NT[index]][NI[index]][:, 0])
                randomint = random.randint(0, nonzero_count - 1)
                newp = Feature_bestPchorm[NT[index]][NI[index]][randomint][:]
                newm = Feature_bestMchorm[NT[index]][NI[index]][randomint][:]
                newa = Feature_bestAchorm[NT[index]][NI[index]][randomint][:]
                newfit = Feature_Table[NT[index]][NI[index]][randomint][:]

                P_pool = np.zeros(shape=(2, SH), dtype=int)
                M_pool = np.zeros(shape=(2, SH), dtype=int)
                A_pool = np.zeros(shape=(2, SH), dtype=int)
                P_pool[0, :] = newp
                M_pool[0, :] = newm
                A_pool[0, :] = newa

                randomint = random.randint(0, int(Plen) - 1)
                P_pool[1, :] = AP[randomint][:]
                M_pool[1, :] = AM[randomint][:]
                A_pool[1, :] = AA[randomint][:]
                P1, M1, A1, P2, M2, A2, index1, index2 = evolution3(P_pool, M_pool, A_pool, A, SH, N, H, NM, M, 2)

                Fit1[0], Fit1[1], NT2, NI2, TransTime_Oper = CalfitFJFP2(P1, M1, A1, A, N, H, TM, ptime, TransTime,
                                                                         Ep, TransTime_Oper)
                Fit2[0], Fit2[1], NT3, NI3, TransTime_Oper2 = CalfitFJFP2(P2, M2, A2, A, N, H, TM, ptime, TransTime,
                                                                         Ep, TransTime_Oper)

                NFEs = NFEs + 2

                dom = NDS(Fit1, Fit2)
                if dom == 1:
                    newp = P1
                    newm = M1
                    newa = A1
                    newfit = Fit1
                    BP = np.vstack((BP, P1))
                    BM = np.vstack((BM, M1))
                    BA = np.vstack((BA, A1))
                    Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, reward = Update_FeatureSpace(
                        P1, M1, A1, Fit1, Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm,
                        NT, NI, NT2, NI2, P)
                elif dom == 0 and Fit2[0] != Fit1[0] and Fit2[1] != Fit1[1]:
                    randomint = random.randint(0, 1)
                    if randomint == 0:
                        newp = P1
                        newm = M1
                        newa = A1
                        newfit = Fit1
                        BP = np.vstack((BP, P1))
                        BM = np.vstack((BM, M1))
                        BA = np.vstack((BA, A1))
                        BFit = np.vstack((BFit, Fit1))
                        Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, reward = Update_FeatureSpace(
                            P1, M1, A1, Fit1, Feature_Table, Feature_bestPchorm, Feature_bestMchorm,
                            Feature_bestAchorm, NT, NI, NT2, NI2, P)
                    else:
                        newp = P2
                        newm = M2
                        newa = A2
                        newfit = Fit2
                        # machine_idletime = machine_idletime2
                        TransTime_Oper = TransTime_Oper2
                        BP = np.vstack((BP, P2))
                        BM = np.vstack((BM, M2))
                        BA = np.vstack((BA, A2))
                        BFit = np.vstack((BFit, Fit2))
                        Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, reward = Update_FeatureSpace(
                            P1, M1, A1, Fit1, Feature_Table, Feature_bestPchorm, Feature_bestMchorm,
                            Feature_bestAchorm, NT, NI, NT3, NI3, P)
                else:
                    newp = P2
                    newm = M2
                    newa = A2
                    newfit = Fit2
                    # machine_idletime = machine_idletime2
                    TransTime_Oper= TransTime_Oper2
                    BP = np.vstack((BP, P2))
                    BM = np.vstack((BM, M2))
                    BA = np.vstack((BA, A2))
                    BFit = np.vstack((BFit, Fit2))
                    Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, reward = Update_FeatureSpace(
                        P1, M1, A1, Fit1, Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm,
                        NT, NI, NT3, NI3, P)

                current_state[0:SH] = copy.copy(newp)
                current_state[SH:SH * 2] = copy.copy(newm)
                current_state[SH * 2:SH * 2 + SH] = copy.copy(newa)
                action = dq_net.choose_action(current_state)

                action = int(action)

                if action == 0:

                    P1, M1, A1 = LS2(P1, M1, A1, N, H, SH, ptime, TM, NM, M, TransTime, TransTime_Oper)
                elif action == 1:
                    P1, M1, A1 = LS3(P1, M1, A1, N, H, SH, ptime, TM, NM, M, TransTime, TransTime_Oper)
                elif action == 2:
                    P1, M1, A1 = LS4(P1, M1, A1, newfit, N, H, SH, ptime, TM, TransTime, TransTime_Oper)
                elif action == 3:
                    P1, M1, A1 = LS5(P1, M1, A1, A, newfit, N, H, SH, ptime, TM, NM, M, TransTime, TransTime_Oper)
                elif action == 4:
                    P1, M1, A1 = LS6(P1, M1, A1, newfit, N, H, SH, ptime, TM, TransTime, TransTime_Oper)

                TransTime_Oper = np.zeros(shape=(N, opmax))
                Fit1[0], Fit1[1], NT2, NI2, TransTime_Oper = CalfitFJFP2(P1, M1, A1, A, N, H, TM, ptime, TransTime,
                                                                         Ep, TransTime_Oper)
                NFEs = NFEs + 1

                BP = np.vstack((BP, P1))
                BM = np.vstack((BM, M1))
                BA = np.vstack((BA, A1))
                BFit = np.vstack((BFit, Fit1))
                Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, reward, actionnum = Update_FeatureSpace2(
                    P1, M1, A1, Fit1, Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, NT2, NI2, P, action, actionnum)

                next_state[0:SH] = copy.copy(P1)
                next_state[SH:SH * 2] = copy.copy(M1)
                next_state[SH * 2:SH * 2 + SH] = copy.copy(A1)

                dq_net.store_transition(current_state, action, reward, next_state)
                if dq_net.memory_counter > MEMORY_CAPACITY:
                    for epoch in range(EPOCH):
                        loss = dq_net.learn()
                        Loss.append(loss)

            AP = BP
            AM = BM
            AA = BA
            AFit = BFit

            end_time = time.time()

            execution_time = end_time - start_time


    print('finish '+FileName[file])
print('finish running')
