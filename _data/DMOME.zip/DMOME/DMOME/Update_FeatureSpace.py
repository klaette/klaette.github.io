import copy
import random
from Tool import *
import numpy as np
from quality_indicator import *

def Update_FeatureSpace(P1,M1, A1, Fit1, Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, NT2, NI2,P):
    if Feature_Table[NT2][NI2][0][0] == 0:
        Feature_Table[NT2][NI2][0][:] = Fit1
        Feature_bestPchorm[NT2][NI2][0][:] = P1
        Feature_bestMchorm[NT2][NI2][0][:] = M1
        Feature_bestAchorm[NT2][NI2][0][:] = A1
        NT = np.append(NT, NT2)
        NI = np.append(NI, NI2)
        reward = 1
    else:
        QFit = Fit1
        for ii in range(P):
            if Feature_Table[NT2][NI2][ii][0] != 0:
                QFit = np.vstack((QFit, Feature_Table[NT2][NI2][ii][:]))
        PF = pareto(QFit)
        if PF[0] == 0 and len(PF) > P:
            result = np.zeros(len(PF), dtype=float)
            for jj in range(len(QFit)-1):
                QFit_new = np.delete(QFit, jj, axis=0)
                hypervolume = HyperVolume(reference_point=[1.1, 1.1])
                # 准备输入数据
                # 分别对第一列和第二列进行归一化
                QFit_new_normalized = QFit_new.copy()

                # 对第一列归一化
                QFit_new_normalized[:, 0] = (QFit_new[:, 0] - QFit_new[:, 0].min()) / (
                            QFit_new[:, 0].max() - QFit_new[:, 0].min())

                # 对第二列归一化
                QFit_new_normalized[:, 1] = (QFit_new[:, 1] - QFit_new[:, 1].min()) / (
                            QFit_new[:, 1].max() - QFit_new[:, 1].min())
                solutions = QFit_new_normalized
                # 计算超体积
                result[jj] = hypervolume.compute(solutions)
                # 处理结果
            max_index = np.argmax(result)

            Feature_Table[NT2][NI2][max_index][:] = Fit1
            Feature_bestPchorm[NT2][NI2][max_index][:] = P1
            Feature_bestMchorm[NT2][NI2][max_index][:] = M1
            Feature_bestAchorm[NT2][NI2][max_index][:] = A1
            NT = np.append(NT, NT2)
            NI = np.append(NI, NI2)
            reward = 0.8


        elif PF[0] == 0 and len(PF) < P + 1:
            Feature_Table[NT2][NI2][len(PF) - 1][:] = Fit1
            Feature_bestPchorm[NT2][NI2][len(PF) - 1][:] = P1
            Feature_bestMchorm[NT2][NI2][len(PF) - 1][:] = M1
            Feature_bestAchorm[NT2][NI2][len(PF) - 1][:] = A1
            NT = np.append(NT, NT2)
            NI = np.append(NI, NI2)
            reward = 1
        else:
            reward = 0

    return Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI,reward

def Update_FeatureSpace2(P1,M1, A1, Fit1, Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI, NT2, NI2,P,k,actionnum):
    if Feature_Table[NT2][NI2][0][0] == 0:
        Feature_Table[NT2][NI2][0][:] = Fit1
        Feature_bestPchorm[NT2][NI2][0][:] = P1
        Feature_bestMchorm[NT2][NI2][0][:] = M1
        Feature_bestAchorm[NT2][NI2][0][:] = A1
        NT = np.append(NT, NT2)
        NI = np.append(NI, NI2)
        reward = 1
        actionnum[k] = actionnum[k] + 1
    else:
        QFit = Fit1
        for ii in range(P):
            if Feature_Table[NT2][NI2][ii][0] != 0:
                QFit = np.vstack((QFit, Feature_Table[NT2][NI2][ii][:]))
        PF = pareto(QFit)
        if PF[0] == 0 and len(PF) > P:
            random_int = random.randint(1, P - 1)
            Feature_Table[NT2][NI2][random_int][:] = Fit1
            Feature_bestPchorm[NT2][NI2][random_int][:] = P1
            Feature_bestMchorm[NT2][NI2][random_int][:] = M1
            Feature_bestAchorm[NT2][NI2][random_int][:] = A1
            NT = np.append(NT, NT2)
            NI = np.append(NI, NI2)
            reward = 0.8
            actionnum[k] = actionnum[k] + 1
        elif PF[0] == 0 and len(PF) < P + 1:
            Feature_Table[NT2][NI2][len(PF) - 1][:] = Fit1
            Feature_bestPchorm[NT2][NI2][len(PF) - 1][:] = P1
            Feature_bestMchorm[NT2][NI2][len(PF) - 1][:] = M1
            Feature_bestAchorm[NT2][NI2][len(PF) - 1][:] = A1
            NT = np.append(NT, NT2)
            NI = np.append(NI, NI2)
            reward = 1
            actionnum[k] = actionnum[k] + 1
        else:
            reward = 0

    return Feature_Table, Feature_bestPchorm, Feature_bestMchorm, Feature_bestAchorm, NT, NI,reward,actionnum