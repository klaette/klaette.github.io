import numpy as np

def GD(PopObj, PF):
    # Distance = np.min(np.linalg.norm(PopObj - PF, axis=1))
    # Score = np.linalg.norm(Distance) / len(Distance)
    # 归一化目标函数集
    normalized_objective_set = (PopObj - np.min(PopObj, axis=0)) / (np.max(PopObj, axis=0) - np.min(PopObj, axis=0))
    normalized_PF = (PF - np.min(PF, axis=0)) / (np.max(PF, axis=0) - np.min(PF, axis=0))
    # 计算每个帕累托解到最近归一化目标函数的距离的平方和
    distances = np.min(np.linalg.norm(normalized_PF[:, np.newaxis] - normalized_objective_set, axis=2), axis=1)
    Score = np.sqrt(np.mean(distances ** 2))
    return Score