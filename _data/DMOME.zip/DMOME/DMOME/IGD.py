import numpy as np

def IGD(PF, PopObj):
    normalized_pareto_set = (PF - np.min(PF, axis=0)) / (np.max(PF, axis=0) - np.min(PF, axis=0))
    normalized_objective_set = (PopObj - np.min(PopObj, axis=0)) / (np.max(PopObj, axis=0) - np.min(PopObj, axis=0))
    # 计算每个归一化帕累托解与归一化目标函数集之间的欧氏距离
    distances = np.min(np.linalg.norm(normalized_pareto_set[:, np.newaxis] - normalized_objective_set, axis=2), axis=1)
    # 计算IGD
    Score = np.mean(distances)
    return Score