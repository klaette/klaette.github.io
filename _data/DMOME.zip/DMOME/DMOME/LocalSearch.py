# coding:utf-8
#problem specific local search
import copy
import random
from fitFJSP import *
import numpy as np
from CriticalPath import FindCriticalPathDHFJSP

#Swap out of factory
def SwapOF(p_chrom,m_chrom,f_chrom,fitness,N,H,SH,time):
    Index1=np.floor(random.random()*SH)
    Index2 = np.floor(random.random() * SH)
    while Index1==Index2:
        Index2 = np.floor(random.random() * SH)
    newp=p_chrom
    newm=m_chrom
    newf=f_chrom
    Index1=int(Index1);Index2=int(Index2)
    tmp = copy.copy(newp[Index1]);
    newp[Index1] = copy.copy(newp[Index2])# 交换两点的染色体值
    newp[Index2] = copy.copy(tmp);
    return newp,newm,newf

#Swap in critical factory
def SwapIF(p_chrom,m_chrom,f_chrom,fitness,N,H,SH,time,F):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    P0 = [];
    P = [];
    IP = []
    FJ = []
    for f in range(F):
        P.append([])
        IP.append([])
        FJ.append([])

    for i in range(SH):
        t1 = s1[i]
        t2 = s2[i]
        t3 = f_chrom[t1]
        P[t3].append(p_chrom[i])
        IP[t3].append(i)
    for i in range(N):
        t3 = f_chrom[i]
        FJ[t3].append(i)

    cf = int(fitness[1])
    L=len(IP[cf])
    Index1=np.floor(random.random()*L)
    Index2 = np.floor(random.random() * L)
    while Index1==Index2:
        Index2 = np.floor(random.random() * L)
    newp=p_chrom
    newm=m_chrom
    newf=f_chrom
    Index1=int(Index1);Index2=int(Index2)
    Index1=IP[cf][Index1];Index2=IP[cf][Index2]
    tmp = copy.copy(newp[Index1]);
    newp[Index1] = copy.copy(newp[Index2])# 交换两点的染色体值
    newp[Index2] = copy.copy(tmp);
    return newp,newm,newf



#find a critical operation and randomly change a job to another factory according to its total processing time / machine
#the lower total processing time the bigger probability of the factory will be selected
#select method is roulette
def RankFA(p_chrom,m_chrom,f_chrom,fitness,N,H,SH,time,TM,NM,M,F,ProF,TransTime):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    P0 = [];
    P = [];
    FJ = []
    for f in range(F):
        P.append([])
        FJ.append([])

    for i in range(SH):
        t1 = s1[i]
        t2 = s2[i]
        t3 = f_chrom[t1]
        P[t3].append(p_chrom[i])
    for i in range(N):
        t3 = f_chrom[i]
        FJ[t3].append(i)

    cf=int(fitness[1])
    CP,_,_=FindCriticalPathDHFJSP(P[cf],m_chrom,FJ[cf],cf,N,H,time,TM,TransTime)
    L=len(CP)
    IndexO=CP[int(np.floor(random.random()*L))]
    s3=copy.copy(P[cf])
    I2=s3[IndexO]

    pro=ProF[I2,:]
    pro_index=np.argsort(pro)
    for f in range(1,F):
        pro[pro_index[f]]=pro[pro_index[f]]+pro[pro_index[f-1]]
    x=random.random()
    for f in range(F):
        if x<pro[pro_index[f]]:
            of=pro_index[f]
            break

    of=int(np.floor(random.random()*F))
    while of==cf:
        x = random.random()
        for f in range(F):
            if x < pro[pro_index[f]]:
                of = pro_index[f]
                break
    newf=copy.copy(f_chrom)
    newf[I2]=int(of)
    return p_chrom, m_chrom, newf

#Randomly select a operation and assiged to another machine 为关键工厂中某个关键路径上的工序换加工机器，但这个策略有可能有没有改变加工机器的概率
def RandMS(p_chrom,m_chrom,f_chrom,fitness,N,H,SH,time,TM,NM,M,F,TransTime):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    P0 = [];
    P = [];
    FJ = []
    for f in range(F):
        P.append([])
        FJ.append([])

    for i in range(SH):
        t1 = s1[i]
        t2 = s2[i]
        t3 = f_chrom[t1]
        P[t3].append(p_chrom[i])
    for i in range(N):
        t3 = f_chrom[i]
        FJ[t3].append(i)

    cf = int(fitness[1])
    CP, _, _ = FindCriticalPathDHFJSP(P[cf], m_chrom, FJ[cf], cf, N, H, time, TM,TransTime)
    L = len(CP)
    IndexO = CP[int(np.floor(random.random() * L))]
    s3 = copy.copy(P[cf])
    L = len(s3)
    s4=np.zeros(L)
    p2=np.zeros(N)
    for i in range(L):
        p2[s3[i]] = p2[s3[i]] + 1
        s4[i] = p2[s3[i]]
    I2=s3[IndexO]
    J2=s4[IndexO]
    for i in range(SH):
        if s1[i]==I2 and s2[i]==J2:
            IndexO=i
            break
    I=s1[IndexO];J=s2[IndexO]
    newm=m_chrom
    t4 = 0;t1=I;t2=J;
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]
    tmp = m_chrom[t4 + t2 - 1]
    n=NM[I][J-1]
    cm=np.zeros(n)
    for kk in range(n):
        cm[kk]=M[I][J-1][kk]-1
    Index2=cm[int(np.floor(random.random()*n))]
    newm[t4 + t2 - 1]=int(Index2)
    newp=p_chrom
    return p_chrom, m_chrom, f_chrom

#Randomly select a operation and assiged to another machine
def RankMS(p_chrom,m_chrom,f_chrom,fitness,N,H,SH,time,TM,NM,M,F,TransTime):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    P0 = [];
    P = [];
    FJ = []
    for f in range(F):
        P.append([])
        FJ.append([])

    for i in range(SH):
        t1 = s1[i]
        t2 = s2[i]
        t3 = f_chrom[t1]
        P[t3].append(p_chrom[i])
    for i in range(N):
        t3 = f_chrom[i]
        FJ[t3].append(i)

    cf = int(fitness[1])
    CP, _, _ = FindCriticalPathDHFJSP(P[cf], m_chrom, FJ[cf], cf, N, H, time, TM,TransTime)
    L = len(CP)
    IndexO = CP[int(np.floor(random.random() * L))]
    s3 = copy.copy(P[cf])
    L = len(s3)
    s4=np.zeros(L)
    p2=np.zeros(N)
    for i in range(L):
        p2[s3[i]] = p2[s3[i]] + 1
        s4[i] = p2[s3[i]]
    I2=s3[IndexO]
    J2=s4[IndexO]
    for i in range(SH):
        if s1[i]==I2 and s2[i]==J2:
            IndexO=i
            break
    I=s1[IndexO];J=s2[IndexO]
    newm=m_chrom
    t4 = 0;t1=I;t2=J;
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]
    tmp = m_chrom[t4 + t2 - 1]
    n=NM[I][J-1]
    cm=np.zeros(n,dtype=int)
    cmt=np.zeros(n)
    tot=0
    for kk in range(n):
        cm[kk]=M[I][J-1][kk]-1
        cmt[kk]=time[cf][I][J-1][cm[kk]]
        tot=cmt[kk]+tot
    for kk in range(n):
        cmt[kk]=cmt[kk]/tot
    pro_index=np.argsort(cmt)
    pro = copy.copy(cmt[pro_index])
    for f in range(1,n):
        pro[f]=pro[f]+pro[f-1]
    x=random.random()
    for f in range(n):
        if x<pro[f]:
            Index2=cm[pro_index[f]]
            break

    while tmp==Index2:
        x = random.random()
        for f in range(n):
            if x < pro[f]:
                Index2 = cm[pro_index[f]]
                break
    newm[t4 + t2 - 1]=int(Index2)
    newp=p_chrom
    return p_chrom, m_chrom, f_chrom

def N6(p_chrom,m_chrom,f_chrom,fitness,N,H,SH,time,TM,NM,M,F,TransTime):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]
    P0 = [];
    P = [];IP=[]
    FJ = []
    for f in range(F):
        P.append([])
        IP.append([])
        FJ.append([])

    for i in range(SH):
        t1 = s1[i]
        t2 = s2[i]
        t3 = f_chrom[t1]
        P[t3].append(p_chrom[i])
        IP[t3].append(i)
    for i in range(N):
        t3 = f_chrom[i]
        FJ[t3].append(i)

    cf = int(fitness[1])
    CP, CB, block = FindCriticalPathDHFJSP(P[cf], m_chrom, FJ[cf], cf, N, H, time, TM, TransTime)
    for i in range(block):
        BL=len(CB[i])
        if BL>1:
            if i==0:
                Index1=int(np.floor(random.random()*(BL-1)))
                Index2=BL-1
                Index1=CB[i][Index1];Index2=CB[i][Index2]
                tmp=P[cf][Index1]
                for j in range(Index1,Index2):
                    P[cf][j]=P[cf][j+1]
                P[cf][Index2]=tmp
            if i==block-1:
                Index1=0
                Index2=int(np.floor(random.random()*(BL-1))+1)
                Index1 = CB[i][Index1];Index2 = CB[i][Index2]
                tmp = P[cf][Index2]
                for j in range(Index2, Index1,-1):
                    P[cf][j] = P[cf][j-1]
                P[cf][Index1] = tmp
            if i>0 and i<block-1 and BL>2:
                Index1 = int(np.floor(random.random() * (BL - 2)) + 1)
                Index2=BL-1
                Index1 = CB[i][Index1];Index2 = CB[i][Index2]
                tmp = P[cf][Index1]
                for j in range(Index1, Index2):
                    P[cf][j] = P[cf][j + 1]
                P[cf][Index2] = tmp
                Index1 = 0
                Index2 = int(np.floor(random.random() * (BL - 2)) + 1)
                Index1 = CB[i][Index1];Index2 = CB[i][Index2]
                tmp = P[cf][Index2]
                for j in range(Index2, Index1, -1):
                    P[cf][j] = P[cf][j - 1]
                P[cf][Index1] = tmp
    newm=m_chrom;newf=f_chrom
    newp=np.zeros(SH,dtype=int)
    for f in range(F):
        L=len(IP[f])
        for i in range(L):
            newp[IP[f][i]]=P[f][i]
    return newp,newm,newf

def LS1(p_chrom,m_chrom,a_chrom,A,fitness,N,H,SH,time,TM,NM,M,TransTime,TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]

    cf = 0
    CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)
    L = len(CP)
    IndexO = CP[int(np.floor(random.random() * L))]
    s3 = copy.copy(p_chrom)
    L = len(s3)
    s4=np.zeros(L)
    p2=np.zeros(N)
    for i in range(L):
        p2[s3[i]] = p2[s3[i]] + 1
        s4[i] = p2[s3[i]]
    I2=s3[IndexO]
    J2=s4[IndexO]
    for i in range(SH):
        if s1[i]==I2 and s2[i]==J2:
            IndexO=i
            break
    I=s1[IndexO];J=s2[IndexO]
    newm=m_chrom
    t4 = 0
    t1=I
    t2=J
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]
    tmp = m_chrom[t4 + t2 - 1]
    n=NM[I][J-1]
    cm=np.zeros(n)
    for kk in range(n):
        cm[kk]=M[I][J-1][kk]-1
    Index2=cm[int(np.floor(random.random()*n))]
    if len(cm) != 1:
        while newm[t4 + t2 - 1] == Index2:
            Index2 = cm[int(np.floor(random.random() * n))]
    newm[t4 + t2 - 1]=int(Index2)
    newp=p_chrom
    return newp, newm,a_chrom

# def LS1(p_chrom,m_chrom, a_chrom, N,H,SH,time,TM,NM,M,TransTime, machine_idletime):
#     s1 = p_chrom
#     s2 = np.zeros(SH, dtype=int)
#     p = np.zeros(N, dtype=int)
#     for i in range(SH):
#         p[s1[i]] = p[s1[i]] + 1
#         s2[i] = p[s1[i]]
#
#     L = len(p_chrom)
#
#     newm = m_chrom
#     m_cf = np.zeros(L)
#     for ii in range(L):
#         I = s1[ii]
#         J = s2[ii]
#         t4 = 0
#         t1 = I
#         t2 = J
#         for k in range(t1):  # sum from 0 to t1-1
#             t4 = t4 + H[k]
#         m_cf[ii] = m_chrom[t4 + t2 - 1] #m_cf记录对应s1序列的机器
#
#     sorted_indices = np.argsort(machine_idletime)
#     Minload_Ma = sorted_indices[TM-1]
#     m_index = -1
#
#
#     for i in range(TM):
#         for ii in range(L):
#             if m_cf[ii] == sorted_indices[i]: #若该工序是最大负载机器上的工序
#                 n = NM[s1[ii]][int(s2[ii]) - 1]
#                 if n!= 1:
#                     cm = np.zeros(n)
#                     for kk in range(n):
#                         cm[kk] = M[s1[ii]][int(s2[ii]) - 1][kk] - 1
#                         if cm[kk] == Minload_Ma:  #在最大负载机器上的工序同时也可以在最小负载的机器上加工
#                             m_index = ii
#                             break
#             if m_index != -1:
#                 break
#         if m_index != -1:
#             break
#     t4 = 0
#     t1 = s1[m_index]
#     t2 = int(s2[m_index])
#     for k in range(t1):  # sum from 0 to t1-1
#         t4 = t4 + H[k]
#
#     newm[t4 + t2 - 1] = Minload_Ma
#     newp=p_chrom
#     newa = a_chrom
#     return newp, newm, newa

def LS2(p_chrom,m_chrom, a_chrom, N,H,SH,time,TM,NM,M,TransTime, TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]

    newm = m_chrom

    index = int(np.floor(random.random() * N))
    max_indice = np.argmax(TransTime_Oper[index])
    while np.max(TransTime_Oper[index]) == 0:
        index = int(np.floor(random.random() * N))
        max_indice = np.argmax(TransTime_Oper[index])
    n = NM[index][max_indice]
    cm = np.zeros(n)
    for kk in range(n):
        cm[kk] = M[index][max_indice][kk] - 1

    t1 = index
    t2 = max_indice
    t4 = 0
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]
    Index2 = cm[int(np.floor(random.random() * n))]
    if len(cm) != 1:
        while newm[t4 + t2 - 1] == Index2:
            Index2 = cm[int(np.floor(random.random() * n))]

    newm[t4 + t2 - 1] = int(Index2)
    newp=p_chrom
    return newp, newm, a_chrom

def LS3(p_chrom,m_chrom, a_chrom, N,H,SH,time,TM,NM,M,TransTime, TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]

    cf = 0
    CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)
    LCP = len(CP)
    s3 = np.zeros(LCP, dtype=int)
    s4 = np.zeros(LCP, dtype=int)
    trans = np.zeros(LCP, dtype=int)
    for i in range(LCP):
        s3[i] = s1[CP[i]]
        s4[i] = s2[CP[i]]
        trans[i] = TransTime_Oper[s3[i]][s4[i]-1]

    # 找到数组中最大值的位置序号
    max_indices = np.unravel_index(np.argmax(trans), trans.shape)
    # 分别获取最大值的行索引和列索引

    newm=m_chrom
    n = NM[s3[max_indices]][s4[max_indices]-1]
    cm = np.zeros(n)
    for kk in range(n):
        cm[kk] = M[s3[max_indices]][s4[max_indices]-1][kk] - 1
    Index2 = cm[int(np.floor(random.random() * n))]
    t1 = s3[max_indices]
    t2 = s4[max_indices]
    t4 = 0
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]
    if len(cm) != 1:
        while newm[t4 + t2 - 1] == Index2:
            Index2 = cm[int(np.floor(random.random() * n))]

    newm[t4 + t2 - 1] = int(Index2)
    newp=p_chrom
    return newp, newm, a_chrom

# #找到关键工厂中的某个关键工件，改变它前一台工序所选择的机器，使两道连续的工序机器一致。
# def LS4(p_chrom,m_chrom,N,H,SH,time,TM,NM,M,F,TransTime):
#     s1 = p_chrom
#     s2 = np.zeros(SH, dtype=int)
#     p = np.zeros(N, dtype=int)
#     for i in range(SH):
#         p[s1[i]] = p[s1[i]] + 1
#         s2[i] = p[s1[i]]
#
#     cf = 0
#     CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)
#     L = len(CP)
#     IndexO = CP[int(np.floor(random.random() * L))]
#     s3 = copy.copy(p_chrom)
#     L = len(s3)
#     s4=np.zeros(L)
#     p2=np.zeros(N)
#     newm = m_chrom
#     m_cf=np.zeros(L)
#     for i in range(L):
#         p2[s3[i]] = p2[s3[i]] + 1
#         s4[i] = p2[s3[i]]
#     for ii in range(L):
#         I2 = s3[ii]
#         J2 = s4[ii]
#         for i in range(SH):
#             if s1[i] == I2 and s2[i] == J2:
#                 IndexO = i
#                 break
#         I = s1[IndexO]
#         J = s2[IndexO]
#         t4 = 0
#         t1 = I
#         t2 = J
#         for k in range(t1):  # sum from 0 to t1-1
#             t4 = t4 + H[k]
#         m_cf[ii] = m_chrom[t4 + t2 - 1]
#
#     change = False
#     m_index = 0
#     while change == False:
#         index = int(np.floor(random.random() * L))
#         if s4[index] == 1:
#             for i in range(L):
#                 if s3[i] == s3[index] and s4[i] == 2:
#                     IndexO = i
#                     break
#             if m_cf[IndexO] != m_cf[index]:
#                 n = NM[s3[IndexO]][int(s4[IndexO]) - 1]
#                 cm = np.zeros(n)
#                 for kk in range(n):
#                     cm[kk] = M[s3[IndexO]][int(s4[IndexO]) - 1][kk] - 1
#                     if cm[kk] == m_cf[index]:
#                         m_cf[IndexO] = m_cf[index]
#                         change = True
#                         m_index = IndexO
#                         break
#
#         else:
#             for i in range(L):
#                 if s3[i] == s3[index] and s4[index] == s4[i] + 1:
#                     IndexO = i
#                     break
#             if m_cf[IndexO] != m_cf[index]:
#                 n = NM[s3[IndexO]][int(s4[IndexO]) - 1]
#                 cm = np.zeros(n)
#                 for kk in range(n):
#                     cm[kk] = M[s3[IndexO]][int(s4[IndexO]) - 1][kk] - 1
#                     if cm[kk] == m_cf[index]:
#                         m_cf[index] = m_cf[IndexO]
#                         change = True
#                         m_index = index
#                         break
#
#     t4 = 0
#     t1 = s3[m_index]
#     t2 = int(s4[m_index])
#     for k in range(t1):  # sum from 0 to t1-1
#         t4 = t4 + H[k]
#
#     newm[t4 + t2 - 1]= int(m_cf[m_index])
#
#     newp=p_chrom
#     return newp, newm

#Swap in critical factory 交换关键路径上的工序与另一个同工厂内部的其他工序的位置

def LS4(p_chrom,m_chrom,a_chrom,fitness,N,H,SH,time,TM,TransTime, TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]

    cf = 0
    CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)


    LCP=len(CP)
    Index1 = CP[int(np.floor(random.random()*LCP))]

    index = int(np.floor(random.random() * N))
    max_indice = np.argmax(TransTime_Oper[index])
    while np.max(TransTime_Oper[index]) == 0:
        index = int(np.floor(random.random() * N))
        max_indice = np.argmax(TransTime_Oper[index])

    Index2 = 0
    for i in range(len(p_chrom)):
        if p_chrom[i] == index and max_indice == s2[i]:
            Index2 = i
            break

    while Index1 == Index2:
        Index2 = int(np.floor(random.random() * SH))

    newp=p_chrom
    newm=m_chrom

    tmp = copy.copy(newp[Index1])
    newp[Index1] = copy.copy(newp[Index2])
    newp[Index2] = copy.copy(tmp)
    return newp,newm,a_chrom

#Randomly select a operation and assiged to another machine 为关键工厂中某个关键路径上的工序换加工机器

def LS5(p_chrom,m_chrom,a_chrom,A,fitness,N,H,SH,time,TM,NM,M,TransTime,TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]

    cf = 0
    CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom,  cf, N, H, time, TM, TransTime)
    L = len(CP)
    s3 = np.zeros(L, dtype=float)

    for ii in range(L):
        ope = s2[CP[ii]]
        job = s1[CP[ii]]
        s3[ii] = TransTime_Oper[job][ope-1]

    max_indice = np.argmax(s3)
    t1 = s1[CP[max_indice]]
    t2 = s2[CP[max_indice]]
    t4 = 0
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]

    index_a = 0
    while a_chrom[t4 + t2 - 1] == index_a:
        a_chrom[t4 + t2 - 1] = random.randint(0, A-1)

    newm = m_chrom
    newp = p_chrom
    return newp, newm, a_chrom


def LS6(p_chrom,m_chrom,a_chrom,fitness,N,H,SH,time,TM,TransTime, TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]

    cf = 0
    CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)

    LCP = len(CP)
    index = CP[int(np.floor(random.random() * LCP))]

    max_indice2 = np.argmax(TransTime_Oper[s1[index]])
    while np.max(TransTime_Oper[s1[index]]) == 0:
        index = CP[int(np.floor(random.random() * LCP))]
        max_indice2 = np.argmax(TransTime_Oper[s1[index]])

    Index1 = 0
    for i in range(len(p_chrom)):
        if p_chrom[i] == s1[index] and max_indice2 == s2[i]:
            Index1 = i
            break


    index = int(np.floor(random.random() * N))
    max_indice = np.argmax(TransTime_Oper[index])
    while np.max(TransTime_Oper[index]) == 0:
        index = int(np.floor(random.random() * N))
        max_indice = np.argmax(TransTime_Oper[index])

    Index2 = 0
    for i in range(len(p_chrom)):
        if p_chrom[i] == index and max_indice == s2[i]:
            Index2 = i
            break

    while Index1 == Index2:
        Index2 = int(np.floor(random.random() * SH))

    newp=p_chrom
    newm=m_chrom

    tmp = copy.copy(newp[Index1])
    newp[Index1] = copy.copy(newp[Index2])
    newp[Index2] = copy.copy(tmp)
    return newp,newm,a_chrom


def LS7(p_chrom,m_chrom,a_chrom,A,fitness,N,H,SH,time,TM,NM,M,TransTime,TransTime_Oper):
    s1 = p_chrom
    s2 = np.zeros(SH, dtype=int)
    p = np.zeros(N, dtype=int)
    for i in range(SH):
        p[s1[i]] = p[s1[i]] + 1
        s2[i] = p[s1[i]]

    cf = 0
    CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)
    L = len(CP)
    s3 = np.zeros(L, dtype=float)

    for ii in range(L):
        ope = s2[CP[ii]]
        job = s1[CP[ii]]
        s3[ii] = TransTime_Oper[job][ope - 1]

    max_indice = np.argmax(s3)
    t1 = s1[CP[max_indice]]
    t2 = s2[CP[max_indice]]
    t4 = 0
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]
    index_a = 0
    if a_chrom[t4 + t2 - 1] == index_a:
        a_chrom[t4 + t2 - 1] = 1
    else:
        a_chrom[t4 + t2 - 1] = 0

    rand_indice = random.randint(0, len(s3) - 1)
    while rand_indice == max_indice or s3[rand_indice] == 0:
        rand_indice = random.randint(0, len(s3) - 1)

    t1 = s1[CP[rand_indice]]
    t2 = s2[CP[rand_indice]]
    t4 = 0
    for k in range(t1):  # sum from 0 to t1-1
        t4 = t4 + H[k]

    # index_a = 0
    # if a_chrom[t4 + t2 - 1] == index_a:
    #     a_chrom[t4 + t2 - 1] = 1
    # else:
    #     a_chrom[t4 + t2 - 1] = 0
    index_a = 0
    while a_chrom[t4 + t2 - 1] == index_a:
        a_chrom[t4 + t2 - 1] = random.randint(0, A - 1)

    newm = m_chrom
    newp = p_chrom
    return newp, newm, a_chrom

#选择两个不同的工序,一个关键工序一个随机工序，其中位置靠后工序插入到位置靠前工序的前方。
# def LS6(p_chrom,m_chrom,a_chrom,N,H,SH,time,TM,NM,M,TransTime,TransTime_Oper):
#     s1 = p_chrom
#     s2 = np.zeros(SH, dtype=int)
#     p = np.zeros(N, dtype=int)
#     for i in range(SH):
#         p[s1[i]] = p[s1[i]] + 1
#         s2[i] = p[s1[i]]
#     cf = 0
#     CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)
#     L = len(CP)
#     s3 = np.zeros(L, dtype=float)
#
#     for ii in range(L):
#         ope = s2[CP[ii]]
#         job = s1[CP[ii]]
#         s3[ii] = TransTime_Oper[job][ope - 1]
#
#     max_indice = np.argmax(s3)
#
#     Index1 = CP[max_indice]
#
#
#     Index2 = int(np.floor(random.random() * SH))
#     while Index1 == Index2:
#         Index2 = int(np.floor(random.random() * SH))
#
#     newp = p_chrom
#     newm = m_chrom
#
#     low = min(Index1, Index2)
#     up = max(Index1, Index2)
#     tmp = newp[up]
#     for i in range(up, low, -1):
#         newp[i] = copy.copy(newp[i - 1])
#     newp[low] = copy.copy(tmp)
#
#     return newp, newm, a_chrom



# #随机选择两个不同的工序,其中一个工序插入到另一个的前方。
# def LS7(p_chrom,m_chrom,fitness,N,H,SH,time):
#     Index1 = int(np.floor(random.random() * SH))
#     Index2 = int(np.floor(random.random() * SH))
#     while Index1 == Index2 or p_chrom[Index1] == p_chrom[Index2]:
#         Index2 = int(np.floor(random.random() * SH))
#     newp = p_chrom
#     newm = m_chrom
#
#     low=min(Index1,Index2)
#     up=max(Index1,Index2)
#     tmp = newp[up]
#     for i in range(up,low,-1):
#         newp[i]=copy.copy(newp[i-1])
#     newp[low]=copy.copy(tmp)
#     return newp, newm
#
#
# #随机选择两个不同的工序并交换。
# def LS8(p_chrom,m_chrom,fitness,N,H,SH,time):
#     Index1 = int(np.floor(random.random() * SH))
#     Index2 = int(np.floor(random.random() * SH))
#     while Index1 == Index2 or p_chrom[Index1] == p_chrom[Index2]:
#         Index2 = int(np.floor(random.random() * SH))
#     newp = p_chrom
#     newm = m_chrom
#
#     tmp = copy.copy(newp[Index1])
#     newp[Index1] = copy.copy(newp[Index2])
#     newp[Index2] = copy.copy(tmp)
#     return newp, newm



# def LS6(p_chrom,m_chrom,a_chrom,N,H,SH,time,TM,NM,M,TransTime):
#     cf = 0
#     CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom,  cf, N, H, time, TM, TransTime)
#     L = len(CP)
#     Index1 = int(CP[int(np.floor(random.random() * L))])
#     # Index2 = int(np.floor(random.random() * SH))
#     Index2 = int(np.floor(random.random() * SH))
#     while Index1 == Index2 or p_chrom[Index1] == p_chrom[Index2]:
#         Index2 = int(np.floor(random.random() * SH))
#     newp = p_chrom
#     newm = m_chrom
#
#     low=min(Index1,Index2)
#     up=max(Index1,Index2)
#     tmp = newp[up]
#     for i in range(up,low,-1):
#         newp[i]=copy.copy(newp[i-1])
#     newp[low]=copy.copy(tmp)
#     return newp, newm, a_chrom
#
#
# # def LS6(p_chrom,m_chrom,a_chrom,A,Fit,N,H,SH,time,TM,NM,M,TransTime,NFEs, machine_idletime, TransTime_Oper):
# #     cf = 0
# #     CP, _, _ = FindCriticalPathDHFJSP(p_chrom, m_chrom,  cf, N, H, time, TM, TransTime)
# #     L = len(CP)
# #     Index1 = int(CP[int(np.floor(random.random() * L))])
# #     p_chrom_temp = np.zeros(len(p_chrom), dtype=int)
# #     for i in range(len(p_chrom)):
# #         p_chrom_temp[i] = p_chrom[i]
# #
# #     for i in range(0,len(p_chrom)):
# #         if p_chrom[i] != p_chrom[Index1]:
# #             temp = p_chrom_temp[i]
# #             p_chrom_temp[i] = p_chrom_temp[Index1]
# #             p_chrom_temp[Index1] = temp
# #             # Fit2 = CalfitFJFP3(p_chrom_temp,m_chrom,a_chrom, A, N, H, TM, time, TransTime)
# #             Fit2, _, _,_,_ = CalfitFJFP2(p_chrom_temp,m_chrom,a_chrom, A, N, H, TM, time, TransTime, machine_idletime, TransTime_Oper)
# #             if Fit2 > Fit:
# #                 for i in range(len(p_chrom)):
# #                     p_chrom_temp[i] = p_chrom[i]
# #             else:
# #                 for i in range(len(p_chrom)):
# #                     p_chrom[i] = p_chrom_temp[i]
# #                 Fit = Fit2
# #
# #     return p_chrom_temp, m_chrom, a_chrom, NFEs
#
#
# def LS7(p_chrom,m_chrom,a_chrom,fitness,N,H,SH,time,TM,F,TransTime):
#     s1 = p_chrom
#     s2 = np.zeros(SH, dtype=int)
#     p = np.zeros(N, dtype=int)
#     f_chrom = np.zeros(N, dtype=int)
#     for i in range(SH):
#         p[s1[i]] = p[s1[i]] + 1
#         s2[i] = p[s1[i]]
#
#     P = [];IP=[]
#     FJ = []
#     F = 1
#     for f in range(F):
#         P.append([])
#         IP.append([])
#         FJ.append([])
#
#     for i in range(SH):
#         t1 = s1[i]
#         t2 = s2[i]
#         t3 = f_chrom[t1]
#         P[t3].append(p_chrom[i])
#         IP[t3].append(i)
#     for i in range(N):
#         t3 = f_chrom[i]
#         FJ[t3].append(i)
#
#     cf = 0
#     P = np.array(P)
#     CP, CB, block = FindCriticalPathDHFJSP(p_chrom, m_chrom, cf, N, H, time, TM, TransTime)
#     for i in range(block):
#         BL=len(CB[i])
#         if BL>1:
#             if i==0:
#                 Index1=int(np.floor(random.random()*(BL-1)))
#                 Index2=BL-1
#                 Index1=CB[i][Index1];Index2=CB[i][Index2]
#                 tmp=P[cf][Index1]
#                 for j in range(Index1,Index2):
#                     P[cf][j]=P[cf][j+1]
#                 P[cf][Index2]=tmp
#             if i==block-1:
#                 Index1=0
#                 Index2=int(np.floor(random.random()*(BL-1))+1)
#                 Index1 = CB[i][Index1];Index2 = CB[i][Index2]
#                 tmp = P[cf][Index2]
#                 for j in range(Index2, Index1,-1):
#                     P[cf][j] = P[cf][j-1]
#                 P[cf][Index1] = tmp
#             if i>0 and i<block-1 and BL>2:
#                 Index1 = int(np.floor(random.random() * (BL - 2)) + 1)
#                 Index2=BL-1
#                 Index1 = CB[i][Index1];Index2 = CB[i][Index2]
#                 tmp = P[cf][Index1]
#                 for j in range(Index1, Index2):
#                     P[cf][j] = P[cf][j + 1]
#                 P[cf][Index2] = tmp
#                 Index1 = 0
#                 Index2 = int(np.floor(random.random() * (BL - 2)) + 1)
#                 Index1 = CB[i][Index1];Index2 = CB[i][Index2]
#                 tmp = P[cf][Index2]
#                 for j in range(Index2, Index1, -1):
#                     P[cf][j] = P[cf][j - 1]
#                 P[cf][Index1] = tmp
#     newm=m_chrom
#     newp=np.zeros(SH,dtype=int)
#     for f in range(F):
#         L=len(IP[f])
#         for i in range(L):
#             newp[IP[f][i]]=P[f][i]
#     return newp,newm,a_chrom


